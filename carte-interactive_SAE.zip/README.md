# We Love Green — Carte interactive (SAE)

Front-end Vue.js du plan interactif du festival **We Love Green**.
Les données sont **locales** (fichier JSON), conformément à la consigne S3 :
aucune base de données ni API n'est nécessaire pour tester cette partie.

## Lancer le projet

```bash
npm install
npm run dev      # serveur de développement
npm run build    # build de production dans dist/
```

## Fonctionnalités

- Plan du festival en **SVG** (fortement conseillé par la consigne) : zones colorées
  selon le code couleur du rapport (scènes en violet, Think Tank en bleu foncé,
  comédie en orange, food court en jaune, art en rose, associations en vert, etc.)
- **Une icône par emplacement**, colorée selon sa catégorie
- **Clic sur une icône → zoom animé** sur l'emplacement + fiche d'information
  (nom, description, prestataire associé, jours de présence)
- **Info-bulle au survol** d'un emplacement
- **Légende cliquable** qui sert de filtre par type de prestataire
- Bouton « Voir tout le plan » pour dézoomer (clic sur le fond de la carte aussi)

## Structure

```
src/
├── main.js                        # point d'entrée Vue
├── App.vue                        # page principale (légende/filtre + carte + fiche)
├── data/
│   └── lieux.json                 # SOURCE DE DONNÉES LOCALE (catégories + emplacements)
└── components/
    ├── CarteInteractive.vue       # carte SVG, marqueurs, zoom animé (viewBox), info-bulle
    └── FicheLieu.vue              # panneau d'information du lieu sélectionné
```

## Ajouter / modifier un emplacement

Tout se fait dans `src/data/lieux.json` : chaque lieu a un `id`, un `nom`,
une `categorie` (référence à la liste `categories`), des coordonnées `x` / `y`
(dans le repère SVG de 1000×700), une `description`, un `prestataire`
(ou `null`) et ses `jours` de présence.

## Comptes de test

Aucun compte nécessaire pour cette partie (carte publique).
Les logins prestataire / organisateur seront documentés ici quand
l'authentification sera implémentée.
