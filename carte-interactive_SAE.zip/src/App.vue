<script setup>
import { ref, computed } from 'vue'
import donnees from './data/lieux.json'
import CarteInteractive from './components/CarteInteractive.vue'
import FicheLieu from './components/FicheLieu.vue'

// --- Données locales (source de données = fichier JSON, pas de BdD) ---
const categories = donnees.categories
const lieux = donnees.lieux

// Catégories actuellement visibles sur la carte (filtre)
const categoriesVisibles = ref(categories.map((c) => c.id))

// Lieu sélectionné (clic sur une icône -> zoom + fiche)
const lieuSelectionne = ref(null)

function basculerCategorie(id) {
  const i = categoriesVisibles.value.indexOf(id)
  if (i === -1) categoriesVisibles.value.push(id)
  else categoriesVisibles.value.splice(i, 1)
}

// Lieux affichés après filtrage
const lieuxFiltres = computed(() =>
  lieux.filter((l) => categoriesVisibles.value.includes(l.categorie))
)

function couleurCategorie(idCategorie) {
  const cat = categories.find((c) => c.id === idCategorie)
  return cat ? cat.couleur : '#999'
}

function selectionnerLieu(lieu) {
  lieuSelectionne.value = lieu
}

function deselectionner() {
  lieuSelectionne.value = null
}
</script>

<template>
  <div class="page">
    <header class="entete">
      <h1>We Love Green</h1>
      <p>Plan interactif du festival — cliquez sur une icône pour zoomer sur un emplacement</p>
    </header>

    <!-- Légende + filtre par type de prestataire -->
    <nav class="legende" aria-label="Légende et filtres">
      <button
        v-for="cat in categories"
        :key="cat.id"
        class="badge"
        :class="{ inactif: !categoriesVisibles.includes(cat.id) }"
        @click="basculerCategorie(cat.id)"
      >
        <span class="pastille" :style="{ backgroundColor: cat.couleur }">{{ cat.icone }}</span>
        {{ cat.nom }}
      </button>
    </nav>

    <main class="contenu">
      <CarteInteractive
        :lieux="lieuxFiltres"
        :categories="categories"
        :lieu-selectionne="lieuSelectionne"
        @select="selectionnerLieu"
        @reset="deselectionner"
      />

      <FicheLieu
        v-if="lieuSelectionne"
        :lieu="lieuSelectionne"
        :couleur="couleurCategorie(lieuSelectionne.categorie)"
        @fermer="deselectionner"
      />
    </main>

    <footer class="pied">
      Projet SAE — We Love Green · Données locales (fichier JSON), sans base de données
    </footer>
  </div>
</template>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  font-family: 'Segoe UI', Arial, sans-serif;
  background: #f2f7ee;
  color: #23301f;
}

.page {
  min-height: 100dvh;
  display: flex;
  flex-direction: column;
}

.entete {
  background: #1b5e20;
  color: #f2f7ee;
  padding: 16px 24px;
}
.entete h1 { font-size: 1.6rem; letter-spacing: 0.5px; }
.entete p { font-size: 0.95rem; opacity: 0.9; margin-top: 4px; }

.legende {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 12px 24px;
  background: #ffffff;
  border-bottom: 1px solid #dde7d4;
}
.badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: 1px solid #cfdcc6;
  background: #fff;
  border-radius: 999px;
  padding: 6px 12px;
  font-size: 0.85rem;
  cursor: pointer;
  transition: opacity 0.2s, transform 0.15s;
}
.badge:hover { transform: translateY(-1px); }
.badge.inactif { opacity: 0.35; }
.pastille {
  width: 22px; height: 22px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
}

.contenu {
  flex: 1;
  display: flex;
  gap: 16px;
  padding: 16px 24px;
  align-items: flex-start;
  flex-wrap: wrap;
}

.pied {
  padding: 10px 24px;
  font-size: 0.8rem;
  color: #6b7a63;
  text-align: center;
}
</style>
