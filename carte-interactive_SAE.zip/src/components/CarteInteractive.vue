<script setup>
import { ref, computed } from 'vue'

// Props reçues depuis App.vue
const props = defineProps({
  lieux: { type: Array, required: true },
  categories: { type: Array, required: true },
  lieuSelectionne: { type: Object, default: null }
})
const emit = defineEmits(['select', 'reset'])

// ------------------------------------------------------------------
// Gestion du zoom : on anime le viewBox du SVG
// Vue complète : "0 0 1000 700" ; zoom : fenêtre de 320x224 centrée
// sur le lieu cliqué.
// ------------------------------------------------------------------
const VUE_COMPLETE = { x: 0, y: 0, w: 1000, h: 700 }
const viewBox = ref({ ...VUE_COMPLETE })
let animation = null

const viewBoxTexte = computed(
  () => `${viewBox.value.x} ${viewBox.value.y} ${viewBox.value.w} ${viewBox.value.h}`
)

// Interpolation douce (ease-out) entre deux viewBox
function animerViewBox(cible, duree = 450) {
  if (animation) cancelAnimationFrame(animation)
  const depart = { ...viewBox.value }
  const debut = performance.now()

  function etape(maintenant) {
    const t = Math.min((maintenant - debut) / duree, 1)
    const e = 1 - Math.pow(1 - t, 3) // ease-out cubique
    viewBox.value = {
      x: depart.x + (cible.x - depart.x) * e,
      y: depart.y + (cible.y - depart.y) * e,
      w: depart.w + (cible.w - depart.w) * e,
      h: depart.h + (cible.h - depart.h) * e
    }
    if (t < 1) animation = requestAnimationFrame(etape)
  }
  animation = requestAnimationFrame(etape)
}

// Clic sur une icône : on sélectionne le lieu et on zoome dessus
function cliquerLieu(lieu) {
  emit('select', lieu)
  const w = 420
  const h = 294
  const x = Math.min(Math.max(lieu.x - w / 2, 0), VUE_COMPLETE.w - w)
  const y = Math.min(Math.max(lieu.y - h / 2, 0), VUE_COMPLETE.h - h)
  animerViewBox({ x, y, w, h })
}

// Bouton "voir tout" : retour à la vue complète
function reinitialiser() {
  emit('reset')
  animerViewBox({ ...VUE_COMPLETE })
}

// ------------------------------------------------------------------
// Info-bulle au survol d'une icône
// ------------------------------------------------------------------
const lieuSurvole = ref(null)

function categorieDu(idCategorie) {
  return props.categories.find((c) => c.id === idCategorie) || {}
}
</script>

<template>
  <div class="carte-conteneur">
    <svg
      :viewBox="viewBoxTexte"
      class="carte"
      role="img"
      aria-label="Plan interactif du festival We Love Green"
      @click.self="reinitialiser"
    >
      <!-- ====== Décor : le parc (10 ha, cadre boisé) ====== -->
      <rect x="0" y="0" width="1000" height="700" fill="#b7d9a3" />

      <!-- Zones boisées -->
      <g fill="#8fbf7a">
        <ellipse cx="90" cy="90" rx="90" ry="70" />
        <ellipse cx="470" cy="70" rx="150" ry="55" />
        <ellipse cx="930" cy="90" rx="110" ry="75" />
        <ellipse cx="60" cy="300" rx="70" ry="110" />
        <ellipse cx="950" cy="420" rx="80" ry="120" />
        <ellipse cx="150" cy="660" rx="120" ry="45" />
      </g>
      <!-- Arbres -->
      <g fill="#6aa854">
        <circle cx="120" cy="110" r="16" /><circle cx="70" cy="80" r="12" />
        <circle cx="430" cy="60" r="13" /><circle cx="510" cy="70" r="15" />
        <circle cx="920" cy="70" r="14" /><circle cx="960" cy="120" r="12" />
        <circle cx="55" cy="330" r="13" /><circle cx="90" cy="270" r="11" />
        <circle cx="940" cy="400" r="14" /><circle cx="965" cy="470" r="12" />
        <circle cx="130" cy="655" r="12" /><circle cx="190" cy="665" r="10" />
      </g>

      <!-- Chemins (espace praticable, bleu clair) -->
      <g stroke="#bcd9ee" stroke-width="26" fill="none" stroke-linecap="round">
        <path d="M 500 650 L 500 320 L 210 170" />
        <path d="M 500 320 L 790 150" />
        <path d="M 500 320 L 150 380" />
        <path d="M 500 320 L 780 540 L 920 620" />
        <path d="M 500 650 L 920 640" />
        <path d="M 500 320 L 180 540" />
        <path d="M 500 320 L 540 300" />
      </g>

      <!-- ====== Zones colorées (fond des quartiers) ====== -->
      <ellipse cx="200" cy="150" rx="120" ry="80" fill="#7c3aed" opacity="0.12" />
      <ellipse cx="800" cy="140" rx="110" ry="75" fill="#7c3aed" opacity="0.12" />
      <ellipse cx="540" cy="300" rx="90" ry="65" fill="#1d4ed8" opacity="0.12" />
      <ellipse cx="795" cy="540" rx="150" ry="90" fill="#d9a400" opacity="0.14" />
      <ellipse cx="175" cy="555" rx="130" ry="70" fill="#16a34a" opacity="0.12" />
      <ellipse cx="480" cy="210" rx="200" ry="120" fill="#db2777" opacity="0.07" />

      <!-- ====== Emplacements (icônes cliquables) ====== -->
      <g
        v-for="lieu in lieux"
        :key="lieu.id"
        class="marqueur"
        :transform="`translate(${lieu.x}, ${lieu.y})`"
        @click.stop="cliquerLieu(lieu)"
        @mouseenter="lieuSurvole = lieu"
        @mouseleave="lieuSurvole = null"
      >
        <!-- groupe interne : le zoom visuel se fait ici pour ne pas
             écraser le translate du groupe parent -->
        <g class="icone" :class="{ actif: lieuSelectionne && lieuSelectionne.id === lieu.id }">
          <!-- anneau blanc si sélectionné -->
          <circle
            v-if="lieuSelectionne && lieuSelectionne.id === lieu.id"
            r="24"
            fill="none"
            stroke="#ffffff"
            stroke-width="4"
          />
          <circle r="17" :fill="categorieDu(lieu.categorie).couleur" stroke="#ffffff" stroke-width="2.5" />
          <text text-anchor="middle" dominant-baseline="central" font-size="16">
            {{ categorieDu(lieu.categorie).icone }}
          </text>
        </g>
      </g>
    </svg>

    <!-- Info-bulle au survol -->
    <div
      v-if="lieuSurvole"
      class="infobulle"
      :style="{ left: (lieuSurvole.x / 1000) * 100 + '%', top: (lieuSurvole.y / 700) * 100 + '%' }"
    >
      <strong>{{ lieuSurvole.nom }}</strong>
      <span>{{ categorieDu(lieuSurvole.categorie).nom }}</span>
      <em>Cliquez pour zoomer</em>
    </div>

    <!-- Bouton retour vue complète -->
    <button v-if="lieuSelectionne" class="btn-reset" @click="reinitialiser">
      ⟵ Voir tout le plan
    </button>
  </div>
</template>

<style scoped>
.carte-conteneur {
  position: relative;
  flex: 1 1 640px;
  min-width: 300px;
}

.carte {
  width: 100%;
  height: auto;
  display: block;
  border-radius: 12px;
  box-shadow: 0 4px 18px rgba(27, 94, 32, 0.18);
  background: #b7d9a3;
}

.marqueur {
  cursor: pointer;
}
.icone {
  transition: transform 0.15s;
}
.marqueur:hover .icone { transform: scale(1.15); }
.icone.actif { transform: scale(1.2); }

/* Info-bulle positionnée au-dessus du marqueur (coordonnées en %) */
.infobulle {
  position: absolute;
  transform: translate(-50%, -115%);
  background: #ffffff;
  border: 1px solid #cfdcc6;
  border-radius: 8px;
  padding: 8px 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  pointer-events: none;
  display: flex;
  flex-direction: column;
  white-space: nowrap;
  z-index: 10;
}
.infobulle strong { font-size: 0.9rem; }
.infobulle span { font-size: 0.78rem; color: #6b7a63; }
.infobulle em { font-size: 0.72rem; color: #1b5e20; font-style: normal; margin-top: 2px; }

.btn-reset {
  position: absolute;
  top: 12px;
  left: 12px;
  background: #1b5e20;
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 8px 14px;
  font-size: 0.85rem;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
}
.btn-reset:hover { background: #2e7d32; }
</style>
