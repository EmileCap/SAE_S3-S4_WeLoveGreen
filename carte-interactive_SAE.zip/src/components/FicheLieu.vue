<script setup>
// Fiche d'information affichée quand un lieu est sélectionné (clic + zoom)
defineProps({
  lieu: { type: Object, required: true },
  couleur: { type: String, default: '#1b5e20' }
})
defineEmits(['fermer'])
</script>

<template>
  <aside class="fiche" :style="{ borderTopColor: couleur }">
    <button class="fermer" aria-label="Fermer la fiche" @click="$emit('fermer')">✕</button>

    <h2>{{ lieu.nom }}</h2>
    <p class="description">{{ lieu.description }}</p>

    <p v-if="lieu.prestataire" class="ligne">
      <strong>Prestataire :</strong> {{ lieu.prestataire }}
    </p>

    <div class="jours">
      <strong>Jours de présence :</strong>
      <span v-for="jour in lieu.jours" :key="jour" class="jour">{{ jour }}</span>
    </div>
  </aside>
</template>

<style scoped>
.fiche {
  position: relative;
  flex: 0 1 320px;
  min-width: 260px;
  background: #ffffff;
  border: 1px solid #dde7d4;
  border-top: 5px solid #1b5e20;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 4px 14px rgba(27, 94, 32, 0.12);
}

.fiche h2 { font-size: 1.15rem; margin-bottom: 8px; }
.description { font-size: 0.92rem; line-height: 1.5; margin-bottom: 12px; }
.ligne { font-size: 0.88rem; margin-bottom: 10px; }

.jours { font-size: 0.88rem; display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
.jour {
  background: #e8f3e2;
  border: 1px solid #cfdcc6;
  border-radius: 999px;
  padding: 2px 10px;
  font-size: 0.78rem;
}

.fermer {
  position: absolute;
  top: 10px;
  right: 10px;
  border: none;
  background: #eef4e8;
  border-radius: 50%;
  width: 28px;
  height: 28px;
  cursor: pointer;
  font-size: 0.85rem;
  color: #4c5c46;
}
.fermer:hover { background: #dfead4; }
</style>
